#! python3

# SD Computing Studies Assignment

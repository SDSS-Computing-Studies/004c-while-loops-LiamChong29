#! python3

import assignment

def test1():
  assert assignment.function() == expected output

def test2():
  assert "needle" in assignment.function()
  assert "needle2" in assignment.function(),"error Message"

def test3():
  assert assignment.function() == expected output
